# SEO Auditor Pro

A Streamlit-based Python website SEO auditing tool.

## Current features

- Website URL auditing
- HTTPS check
- Title length check
- Meta description length check
- H1 count check
- H2 count
- Image ALT text check
- Canonical tag check
- Robots.txt URL detection
- Sitemap URL detection
- Basic HTTP status
- Link count
- SEO score
- CSV report export

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

Then open the local Streamlit URL shown in the terminal.

## Deployment

This project is structured for deployment from GitHub to Streamlit Community Cloud.

## Important

This is a development build. Before commercial marketplace submission, add automated tests, stronger crawling controls, security hardening, documentation, licensing review, and additional reporting features.
